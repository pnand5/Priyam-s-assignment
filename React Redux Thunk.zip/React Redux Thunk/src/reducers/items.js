
export function studentData(state = [], action) {
    switch (action.type) {
        case 'studentData':
			return state;
        
        default:
            return state;
    }
}
