import { combineReducers } from 'redux';
import {studentData } from './items';

export default combineReducers({
  
    studentData
});
