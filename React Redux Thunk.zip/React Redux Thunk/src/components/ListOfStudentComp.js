import React, { Component, PropTypes } from 'react';

import {browserHistory} from  'react-router';

export default class ListOfStudentComp extends Component{
    constructor(props){
        super(props);
    }
clickHandler(Cid,Sid){
       browserHistory.push(`/studentsOfclass/`+Cid+`/studentReg/`+Sid);


}
    render()
    { 
   var index = this.props.studentData.findIndex((object) =>{ 
            return object.classNumber == this.props.classId
          });
      const currentClass= this.props.studentData[index];

var listOfStudents = currentClass.studentRecord.map((object,index)=> {
    return (<li onClick={this.clickHandler.bind(this,this.props.classId,object.sid)}> Student Regno {object.sid}</li>);
})
        return(
            <div>
                <ul>
                {listOfStudents}
</ul>
            </div>
            );
    }
}