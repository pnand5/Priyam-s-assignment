import React, { Component, PropTypes } from 'react';


export default class InformationComponent extends Component{
    constructor(props){
        super(props);
    }
    render()
    { 
        var classindex = this.props.studentData.findIndex((object) =>{ 
            return object.classNumber == this.props.classId
          });
      const currentClass= this.props.studentData[classindex];

      var studentIndex = currentClass.studentRecord.findIndex((object)=>{
        return object.sid == this.props.studentId
      });
      const currentStudent = currentClass.studentRecord[studentIndex];

      return(
        <div>
            <div className="col-md-12">
                <h4 className="text-center">{this.props.studentId}'s Record </h4>
                <ul>
                <li>DOB: {currentStudent.dob} </li>
                <li>Name: {currentStudent.name} </li>
                <li>GENDER: {currentStudent.gender}</li>
                <li>PARENT'S NAME: {currentStudent.parent}</li>
                </ul>
            </div>
            <p>include ur chart design here only or if u try to make seperate chart Component
            send "currentStudent" as a prop and retrieve data using this.props.currentStudent.maths, this.props.currentStudent.science
            WORK DONE !!! </p>
        </div>
        );
    }
}