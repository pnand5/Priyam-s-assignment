import React, { Component, PropTypes } from 'react';

import ListOfClassComp from './ListOfClassComp'

export default class PresentationBox1 extends Component{
    constructor(props){
        super(props);
    }
    render()
    { 
        return(
            <div className="col-md-12">
                <aside className="col-md-4"> 
                    <ListOfClassComp {...this.props}/>

                </aside>
                <section className="col-md-8">
                    <p> This website helps you to see marks of the students in our school
                    </p>
                </section>

            </div>
            );
    }
}