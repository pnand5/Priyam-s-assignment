const dummyData=[
	{
		"classNumber": 1,
		"studentRecord": [
		{"sid": 1,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 2,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 3,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 4,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 5,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]
	},
	{
		"classNumber": 2,
		"studentRecord": [
		{"sid": 41,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 32,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 23,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 14,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 50,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 3,
		"studentRecord": [
		{"sid": 441,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 332,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 223,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 114,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 500,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 4,
		"studentRecord": [
		{"sid": 101,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 12,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 23,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 34,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 45,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 5,
		"studentRecord": [
		{"sid": 102,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 112,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 223,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 334,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 445,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 6,
		"studentRecord": [
		{"sid": 1033,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 1112,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 2223,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 3334,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 4445,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 7,
		"studentRecord": [
		{"sid": 10,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 21,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 32,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 43,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 54,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 8,
		"studentRecord": [
		{"sid": 100,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 211,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 322,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 433,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 544,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 9,
		"studentRecord": [
		{"sid": 1000,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 2111,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 3222,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 4333,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 5444,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]
	},
	{
		"classNumber": 10,
		"studentRecord": [
		{"sid": 11,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 22,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 33,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 44,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 55,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 11,
		"studentRecord": [
		{"sid": 111,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 222,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 333,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 444,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 555,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	},
	{
		"classNumber": 12,
		"studentRecord": [
		{"sid": 1111,"name":"faerleaf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 2222,"name":"agseng","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 3333,"name":"ggat","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 4444,"name":"asd","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		{"sid": 5555,"name":"bafadbsf","dob":"1-1-96", "gender":"male","parent": "abc","maths":100,"science":99,"English":98},
		

		]

	}
];
export default dummyData;